#ifndef BSP_KEY_IRQ_H_
#define BSP_KEY_IRQ_H_

#include "hal_data.h"

void IRQ_Init(void);

#endif
